from sqlalchemy.ext.declarative import declarative_base

EntityBase = declarative_base()

