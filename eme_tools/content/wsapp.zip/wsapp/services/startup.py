


def init(server):
    # website startup script
    pass
