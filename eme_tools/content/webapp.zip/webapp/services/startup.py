from core.ctx import get_session, get_redis
from core.dal import users



def init(server):
    # website startup script
    pass
