
from webapp.website import ExampleWebsite

# same as if you were executing simple_website/webapp/website.py
# with working directory: simple_website
app = ExampleWebsite()
app.start()
